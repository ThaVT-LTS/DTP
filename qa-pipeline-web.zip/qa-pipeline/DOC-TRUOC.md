# Đọc trước — bản dùng cho chat web

Gói này là bản sao của thư mục `qa-pipeline`, xuất ngày 2026-10-09.

Việc cần làm khi nhận gói này trong một chat:
1. Giải nén vào thư mục làm việc, giữ nguyên cấu trúc.
2. Đọc `CLAUDE.md`, rồi `rules/common.md` và `rules/feedback.md`. Rule khác đọc theo việc đang làm.
3. Đường dẫn `skills/…` trong rule và skill nghĩa là `.claude/skills/…`.
4. Tài liệu dự án không có trong gói. Người dùng sẽ đính kèm tài liệu cần làm; đặt nó vào `projects/<dự-án>/docs/source/` (sao chép từ `projects/_template`).
5. Mọi file kết quả phải gửi lại cho người dùng dưới dạng file, kèm đường dẫn nơi nó thuộc về trong `qa-pipeline`, để người dùng chép về thư mục gốc. Chat này không ghi được vào thư mục gốc.
6. Sổ `feedback/log.md` trong gói là bản sao. Bản ghi FB mới phải gửi lại cho người dùng để gộp vào sổ gốc; không coi sổ trong gói là bản mới nhất.
